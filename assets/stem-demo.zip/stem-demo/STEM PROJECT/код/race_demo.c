/*
 * race_demo.c — демонстрація Race Condition (стану гонитви).
 *
 * Кілька потоків одночасно збільшують спільний лічильник counter.
 * Операція counter++ НЕ є атомарною: процесор виконує її як
 *   1) LOAD  — прочитати counter з пам'яті в регістр;
 *   2) ADD   — додати 1 у регістрі;
 *   3) STORE — записати результат назад у пам'ять.
 * Якщо два потоки прочитали однакове значення, один із інкрементів
 * губиться (lost update).
 *
 * Збирання:  gcc -O0 -pthread race_demo.c -o race_demo
 * Запуск:    ./race_demo [потоків] [ітерацій] [--mutex]
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static long counter = 0;                 /* спільний ресурс           */
static long iterations = 1000000;        /* інкрементів на потік      */
static int use_mutex = 0;                /* 1 — захистити м'ютексом   */
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static void *worker(void *arg)
{
    (void)arg;
    for (long i = 0; i < iterations; i++) {
        if (use_mutex) pthread_mutex_lock(&lock);    /* вхід у критичну секцію  */
        counter++;                                   /* критична секція         */
        if (use_mutex) pthread_mutex_unlock(&lock);  /* вихід з критичної секції */
    }
    return NULL;
}

int main(int argc, char **argv)
{
    int threads = argc > 1 ? atoi(argv[1]) : 4;
    if (argc > 2) iterations = atol(argv[2]);
    use_mutex = argc > 3 && strcmp(argv[3], "--mutex") == 0;

    pthread_t tid[256];
    for (int t = 0; t < threads; t++)
        pthread_create(&tid[t], NULL, worker, NULL);
    for (int t = 0; t < threads; t++)
        pthread_join(tid[t], NULL);

    long expected = (long)threads * iterations;
    long lost = expected - counter;
    printf("Режим: %-14s потоків: %2d  ітерацій: %ld\n",
           use_mutex ? "з м'ютексом" : "без захисту", threads, iterations);
    printf("Очікувано: %10ld   Отримано: %10ld   Втрачено: %9ld (%.2f %%)  %s\n",
           expected, counter, lost, 100.0 * lost / expected,
           lost == 0 ? "OK" : "<-- RACE CONDITION");
    return 0;
}
