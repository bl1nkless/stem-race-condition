/*
 * litmus_sb.c — лакмус-тест «Store Buffering» (перестановка запис→читання).
 *
 *      Потік 1          Потік 2
 *      X = 1            Y = 1
 *      r1 = Y           r2 = X
 *
 * За «інтуїтивної» (послідовно узгодженої) моделі пам'яті хоча б одне
 * з r1, r2 дорівнює 1. Проте сучасні процесори мають буфер записів:
 * запис X = 1 ще «сидить» у буфері ядра, а читання Y вже виконано.
 * Тоді можливий результат r1 == 0 && r2 == 0.
 *
 *   none  — атомарні читання й записи memory_order_relaxed;
 *   fence — повний апаратний бар'єр atomic_thread_fence(memory_order_seq_cst)
 *           (x86: mfence / lock-префікс, ARM64: dmb ish).
 *
 * Потоки синхронізуються спін-бар'єром, щоб стартувати майже одночасно.
 *
 * Збирання:  gcc -O2 -pthread litmus_sb.c -o litmus_sb
 * Запуск:    ./litmus_sb none|fence <ітерацій> [--csv]
 */
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static atomic_int X, Y;
static int r1, r2;
static int use_fence;
static long iters, reorders;
static atomic_int bar_count, bar_gen;

static void spin_barrier(void)                 /* бар'єр для двох потоків */
{
    int g = atomic_load(&bar_gen);
    if (atomic_fetch_add(&bar_count, 1) == 1) {
        atomic_store(&bar_count, 0);
        atomic_fetch_add(&bar_gen, 1);
    } else
        while (atomic_load(&bar_gen) == g) ;
}

static void *worker(void *arg)
{
    int id = (int)(long)arg;
    atomic_int *own = id == 0 ? &X : &Y;
    atomic_int *other = id == 0 ? &Y : &X;
    int *observed = id == 0 ? &r1 : &r2;

    for (long i = 0; i < iters; i++) {
        if (id == 0) {
            atomic_store_explicit(&X, 0, memory_order_relaxed);
            atomic_store_explicit(&Y, 0, memory_order_relaxed);
        }
        spin_barrier();                          /* старт ітерації        */
        atomic_store_explicit(own, 1, memory_order_relaxed);
        if (use_fence)
            atomic_thread_fence(memory_order_seq_cst);
        *observed = atomic_load_explicit(other, memory_order_relaxed);
        spin_barrier();                          /* кінець ітерації       */
        if (id == 0 && r1 == 0 && r2 == 0) reorders++;
    }
    return NULL;
}

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s none|fence iters [--csv]\n", argv[0]); return 1; }
    use_fence = strcmp(argv[1], "fence") == 0;
    iters = atol(argv[2]);
    int csv = argc > 3 && strcmp(argv[3], "--csv") == 0;

    pthread_t a, b;
    pthread_create(&a, NULL, worker, (void *)0L);
    pthread_create(&b, NULL, worker, (void *)1L);
    pthread_join(a, NULL); pthread_join(b, NULL);

    if (csv) printf("%s,%ld,%ld,%.4f\n", argv[1], iters, reorders, 100.0 * reorders / iters);
    else printf("Store Buffering (%s): ітерацій %ld, результат r1=r2=0 спостерігався %ld разів (%.3f %%)\n",
                use_fence ? "з бар'єром seq_cst" : "без бар'єру", iters, reorders, 100.0 * reorders / iters);
    return 0;
}
