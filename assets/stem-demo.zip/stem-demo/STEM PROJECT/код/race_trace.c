/*
 * race_trace.c — покрокова трасування втраченого оновлення (lost update).
 *
 * Модель банківського рахунку: два потоки (два банкомати) одночасно
 * поповнюють рахунок. Між читанням і записом штучно вставлена затримка,
 * щоб «розтягнути» вікно гонитви і зробити чергування операцій видимим.
 *
 * Збирання:  gcc -O0 -pthread race_trace.c -o race_trace
 * Запуск:    ./race_trace           (без синхронізації)
 *            ./race_trace --mutex   (з м'ютексом)
 */
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static int balance = 100;                       /* спільний рахунок, грн */
static int use_mutex = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static struct timespec t0;

typedef struct { const char *name; int amount; int delay_us; } atm_t;

static double ms(void)
{
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return (t.tv_sec - t0.tv_sec) * 1e3 + (t.tv_nsec - t0.tv_nsec) / 1e6;
}

static void *deposit(void *arg)
{
    atm_t *a = arg;
    usleep(a->delay_us);
    if (use_mutex) pthread_mutex_lock(&lock);
    int tmp = balance;                                           /* LOAD  */
    printf("[%6.2f мс] %s: прочитав баланс = %d\n", ms(), a->name, tmp);
    usleep(20000);                          /* «вікно гонитви» 20 мс     */
    tmp += a->amount;                                            /* ADD   */
    balance = tmp;                                               /* STORE */
    printf("[%6.2f мс] %s: записав баланс  = %d (+%d)\n", ms(), a->name, tmp, a->amount);
    if (use_mutex) pthread_mutex_unlock(&lock);
    return NULL;
}

int main(int argc, char **argv)
{
    use_mutex = argc > 1 && strcmp(argv[1], "--mutex") == 0;
    setvbuf(stdout, NULL, _IONBF, 0);
    clock_gettime(CLOCK_MONOTONIC, &t0);
    printf("=== %s ===\nПочатковий баланс: %d грн\n",
           use_mutex ? "З М'ЮТЕКСОМ" : "БЕЗ СИНХРОНІЗАЦІЇ", balance);

    atm_t a = {"Банкомат-1", 50, 0}, b = {"Банкомат-2", 30, 5000};
    pthread_t t1, t2;
    pthread_create(&t1, NULL, deposit, &a);
    pthread_create(&t2, NULL, deposit, &b);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Підсумковий баланс: %d грн (очікувано %d) -> %s\n", balance, 100 + 50 + 30,
           balance == 180 ? "КОРЕКТНО" : "ВТРАЧЕНО ОНОВЛЕННЯ!");
    return 0;
}
