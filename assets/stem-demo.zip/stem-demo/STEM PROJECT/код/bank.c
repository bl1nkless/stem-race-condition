/*
 * bank.c — модель банку: потоки виконують випадкові перекази між рахунками.
 *
 * Інваріант: сума грошей у банку не змінюється, а баланс не стає від'ємним.
 *
 *   none          — без синхронізації (check-then-act + lost update);
 *   global        — один глобальний м'ютекс на весь банк (грубе блокування);
 *   fine_naive    — м'ютекс на кожен рахунок, блокування у порядку (from, to)
 *                   -> можливий взаємне блокування (deadlock);
 *   fine_ordered  — м'ютекс на кожен рахунок, блокування в порядку зростання
 *                   номера рахунку -> deadlock неможливий.
 *
 * Сторожовий потік (watchdog) фіксує deadlock, якщо прогрес зупинився на 1 с.
 *
 * Збирання:  gcc -O2 -pthread bank.c -o bank
 * Запуск:    ./bank none|global|fine_naive|fine_ordered <потоків> <переказів> [--csv]
 */
#define _GNU_SOURCE
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define ACC 10
#define START 1000

static volatile long bal[ACC];
static pthread_mutex_t acc_lock[ACC];
static pthread_mutex_t bank_lock = PTHREAD_MUTEX_INITIALIZER;
static int mode;                 /* 0 none, 1 global, 2 fine_naive, 3 fine_ordered */
static long ops;
static atomic_long progress, negatives;
static atomic_int finished;
static const char *names[] = { "none", "global", "fine_naive", "fine_ordered" };

static void transfer(int from, int to, long amt)
{
    if (bal[from] >= amt) {                /* CHECK               */
        bal[from] -= amt;                  /* ACT: зняти          */
        if (bal[from] < 0) atomic_fetch_add(&negatives, 1);
        bal[to] += amt;                    /* ACT: зарахувати     */
    }
}

static void *worker(void *arg)
{
    unsigned seed = (unsigned)(long)arg * 7919u + 17u;
    for (long i = 0; i < ops; i++) {
        int from = rand_r(&seed) % ACC, to = rand_r(&seed) % ACC;
        if (from == to) to = (to + 1) % ACC;
        long amt = 1 + rand_r(&seed) % 100;
        switch (mode) {
        case 0: transfer(from, to, amt); break;
        case 1:
            pthread_mutex_lock(&bank_lock); transfer(from, to, amt); pthread_mutex_unlock(&bank_lock);
            break;
        case 2:                                     /* небезпечний порядок   */
            pthread_mutex_lock(&acc_lock[from]); pthread_mutex_lock(&acc_lock[to]);
            transfer(from, to, amt);
            pthread_mutex_unlock(&acc_lock[to]); pthread_mutex_unlock(&acc_lock[from]);
            break;
        case 3: {                                   /* впорядковане блокування */
            int lo = from < to ? from : to, hi = from < to ? to : from;
            pthread_mutex_lock(&acc_lock[lo]); pthread_mutex_lock(&acc_lock[hi]);
            transfer(from, to, amt);
            pthread_mutex_unlock(&acc_lock[hi]); pthread_mutex_unlock(&acc_lock[lo]);
            break;
        }
        }
        atomic_fetch_add_explicit(&progress, 1, memory_order_relaxed);
    }
    atomic_fetch_add(&finished, 1);
    return NULL;
}

int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "usage: %s mode threads ops [--csv]\n", argv[0]); return 1; }
    mode = -1;
    for (int i = 0; i < 4; i++) if (strcmp(argv[1], names[i]) == 0) mode = i;
    int threads = atoi(argv[2]);
    ops = atol(argv[3]);
    int csv = argc > 4 && strcmp(argv[4], "--csv") == 0;
    for (int i = 0; i < ACC; i++) { bal[i] = START; pthread_mutex_init(&acc_lock[i], NULL); }

    struct timespec a, b;
    clock_gettime(CLOCK_MONOTONIC, &a);
    pthread_t tid[64];
    for (long t = 0; t < threads; t++) pthread_create(&tid[t], NULL, worker, (void *)t);

    /* watchdog: якщо лічильник прогресу не змінюється 1 с — це deadlock */
    long last = -1; int still = 0, deadlock = 0;
    while (atomic_load(&finished) < threads) {
        usleep(1000);                                   /* опитування кожну 1 мс */
        long p = atomic_load(&progress);
        if (p == last) { if (++still >= 1000) { deadlock = 1; break; } } else still = 0;
        last = p;
    }
    clock_gettime(CLOCK_MONOTONIC, &b);
    if (!deadlock) for (int t = 0; t < threads; t++) pthread_join(tid[t], NULL);

    long total = 0, minb = bal[0];
    for (int i = 0; i < ACC; i++) { total += bal[i]; if (bal[i] < minb) minb = bal[i]; }
    double ms = (b.tv_sec - a.tv_sec) * 1e3 + (b.tv_nsec - a.tv_nsec) / 1e6;
    long done = atomic_load(&progress);

    if (csv)
        printf("%s,%d,%ld,%ld,%ld,%ld,%ld,%ld,%d,%.2f\n", names[mode], threads, ops * threads, done,
               (long)ACC * START, total, total - (long)ACC * START, (long)atomic_load(&negatives), deadlock, ms);
    else {
        printf("Режим: %-12s потоків: %d, переказів: %ld\n", names[mode], threads, ops * threads);
        if (deadlock)
            printf("  !!! DEADLOCK: виконано %ld з %ld переказів, потоки зависли (watchdog 1 с)\n",
                   done, ops * threads);
        printf("  сума в банку: %ld (має бути %d), різниця: %+ld\n", total, ACC * START, total - ACC * START);
        printf("  випадків від'ємного балансу: %ld, мінімальний баланс: %ld\n",
               (long)atomic_load(&negatives), minb);
        printf("  час: %.1f мс -> %s\n", ms,
               deadlock ? "ВЗАЄМНЕ БЛОКУВАННЯ" :
               (total == ACC * START && atomic_load(&negatives) == 0) ? "ІНВАРІАНТ ЗБЕРЕЖЕНО" : "ІНВАРІАНТ ПОРУШЕНО");
    }
    if (deadlock) { fflush(stdout); _exit(3); }
    return 0;
}
