#!/usr/bin/env bash
set -u
set -o pipefail

root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd) || exit 1
vm_dir="$HOME/VirtualBox VMs"
ubuntu_shared="$HOME/VMs/oslabs/lab3_shared"

case "${1:-}" in
  1) lab=1; title='macOS та FreeBSD'; steps=('macOS: версія, ядро, PID 1' 'APFS і захист' 'FreeBSD: ядро, ZFS та jail' 'Порівняння у звіті') ;;
  2) lab=2; title='VirtualBox і Windows'; steps=('Конфігурація та запуск Windows' 'Буфер обміну та перевірка drag-and-drop' 'NAT, USB, DVD та спільна тека' 'Файли ВМ, знімок, збережений стан та OVA') ;;
  3) lab=3; title='VirtualBox і Ubuntu'; steps=('Конфігурація та запуск Ubuntu' 'Буфер обміну та перевірка drag-and-drop' 'NAT, спільна тека, USB, DVD та UEFI' 'Файли ВМ, знімок, збережений стан та OVA') ;;
  4) lab=4; title='Performance Monitor'; steps=('Група Lab та налаштування збирачів' 'Графіки простою та роботи в Paint' 'Підсумки з CSV' 'Час ядра у Диспетчері завдань') ;;
  5) lab=5; title='Об’єкти файлової системи'; steps=('Дерево та прихований каталог' 'Junction, symlink і hard link' 'Томи NTFS і FAT32' 'Підтримка зв’язків і висновок') ;;
  6|stem) lab=6; title='STEM: Race Condition'; steps=('Звіт і постановка задачі' 'Лічильник без захисту та з м’ютексом' 'Трасування втрати оновлення' 'Порівняння способів синхронізації') ;;
  *) printf 'Використання: %s {1|2|3|4|5|stem} [крок|vm]\n' "$0" >&2; exit 2 ;;
esac

max_step=4
if [[ $lab == 6 ]]; then max_step=8; fi
if (( $# > 2 )) || [[ ${2:-0} != [0-"$max_step"] && ${2:-} != vm ]]; then
  printf 'Номер кроку має бути від 0 до %s. Крок 0 відкриває звіт, vm — віртуальну машину ЛР 2–5.\n' "$max_step" >&2
  exit 2
fi
if [[ $(uname -s) != Darwin ]]; then
  printf 'Запусти цей скрипт у Терміналі macOS.\n' >&2
  exit 1
fi

if [[ $lab == 6 ]]; then
  reports=("$root/STEM PROJECT"/Звіт*.pdf)
else
  reports=("$root/lab$lab"/Звіт*.pdf)
fi
report=${reports[0]}

run() {
  printf '$'
  printf ' %q' "$@"
  printf '\n'
  "$@"
}

show() {
  local path
  for path; do
    if [[ ! -e $path ]]; then
      printf 'Не знайдено: %s\n' "$path" >&2
      return 1
    fi
  done
  open "$@"
}

shots() {
  local number pattern
  local -a files=()
  for number; do
    for pattern in "$root/lab$lab/скріншоти/${number}_"*.png; do
      files+=("$pattern")
    done
  done
  show "${files[@]}"
}

vm_start() {
  local name=$1 state
  if ! state=$(VBoxManage showvminfo "$name" --machinereadable 2>/dev/null); then
    sleep 1
    state=$(VBoxManage showvminfo "$name" --machinereadable) || return
  fi
  printf '%s\n' "$state" | grep -E '^(ostype|memory|cpus|nic1|clipboard|draganddrop|VMState)='
  case "$state" in
    *$'\nVMState="running"'*) printf '%s уже запущено.\n' "$name" ;;
    *$'\nVMState="paused"'*) run VBoxManage controlvm "$name" resume ;;
    *) run VBoxManage startvm "$name" --type gui ;;
  esac
}

vm_transfer_demo() {
  local name=$1 folder file
  vm_start "$name" || return
  folder=$(mktemp -d "${TMPDIR:-/tmp}/os-labs-dnd.XXXXXX") || return
  file="$folder/os-lab$lab-dnd.txt"
  printf 'ЛР %s · Перевірка передачі файлу з macOS\n' "$lab" > "$file" || return
  printf 'Файл для перевірки: %s\n' "${file##*/}"
  run open -R "$file"
}

qemu_windows() (
  local home="$HOME/VMs/oslabs/win" firmware='/opt/homebrew/share/qemu/edk2-aarch64-code.fd' run_dir disk
  if pgrep -f '[q]emu-system-aarch64 -name ZAHORSKYI-PC( |$)' >/dev/null; then
    printf 'Windows у QEMU вже запущено.\n'
    return
  fi
  for disk in "$firmware" "$home"/{vars.fd,win.qcow2,lab5disk.qcow2}; do
    if [[ ! -f $disk ]]; then
      printf 'Не знайдено: %s\n' "$disk" >&2
      return 1
    fi
  done
  command -v qemu-system-aarch64 >/dev/null || { printf 'Не знайдено qemu-system-aarch64.\n' >&2; return 1; }
  run_dir=$(mktemp -d /tmp/os-labs-qemu.XXXXXX) || return
  trap '[[ ! -S "$run_dir/qmp.sock" ]] || unlink "$run_dir/qmp.sock"; rmdir "$run_dir"' EXIT
  printf 'Запуск Windows у QEMU.\n'
  qemu-system-aarch64 -name ZAHORSKYI-PC -M virt,highmem=on -accel hvf -cpu host -smp 4 -m 4096 \
    -drive "if=pflash,format=raw,readonly=on,file=$firmware" \
    -drive "if=pflash,format=raw,file=$home/vars.fd" \
    -device virtio-gpu-pci,xres=1440,yres=900 -device qemu-xhci,id=xhci -device usb-kbd -device usb-tablet \
    -drive "if=none,id=hd,file=$home/win.qcow2,format=qcow2,discard=unmap" -device nvme,drive=hd,serial=WINSYS,bootindex=1 \
    -drive "if=none,id=hd2,file=$home/lab5disk.qcow2,format=qcow2" -device nvme,drive=hd2,serial=LAB5DISK \
    -netdev user,id=n0 -device virtio-net-pci,netdev=n0 \
    -qmp "unix:$run_dir/qmp.sock,server=on,wait=off" -display cocoa -rtc base=localtime
)

open_lab_vm() {
  case "$lab" in
    2) vm_start Zahorskyi_Win ;;
    3) vm_start Zahorskyi_Ubuntu ;;
    4|5) qemu_windows ;;
    *) printf 'Для цієї роботи режим vm не передбачено.\n' >&2; return 2 ;;
  esac
}

vm_files() {
  local name=$1 archive=$2
  run VBoxManage snapshot "$name" list || return
  run ls -lh "$vm_dir/$name" "$archive"
}

perf_summary() {
  python3 - "$root/lab4/результати_PerfMon" <<'PY'
import csv
import sys
from pathlib import Path
from statistics import mean

logs = Path(sys.argv[1])
for name in ('idle_modes', 'paint_modes', 'idle_interrupts', 'paint_interrupts'):
    file = logs / f'{name}.csv'
    with file.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream)
        headers = next(reader)
        rows = list(reader)

    print(f'\n{file.name:24} {"N":>3} {"Середнє":>11} {"Макс.":>11}')
    for index, header in enumerate(headers[1:], start=1):
        values = []
        for row in rows:
            if len(row) > index and row[index].strip():
                values.append(float(row[index].replace(',', '.')))
        if values:
            counter = '\\'.join(header.split('\\')[-2:])
            print(f'{counter:39} {len(values):3} {mean(values):11.3f} {max(values):11.3f}')
PY
}

stem_run() (
  local target=$1 build
  shift
  build=$(mktemp -d) || exit 1
  trap 'find "$build" -maxdepth 1 -type f -delete; rmdir "$build"' EXIT
  cp "$root/STEM PROJECT/код/Makefile" "$root/STEM PROJECT/код/$target.c" "$build" || exit 1
  cd "$build" || exit 1
  run make "$target" || exit 1
  case "$target" in
    race_demo)
      run ./race_demo 4 1000000 && run ./race_demo 4 1000000 --mutex ;;
    race_trace)
      run ./race_trace && run ./race_trace --mutex ;;
    bank)
      run "./$target" "$@" ;;
    litmus_sb)
      run ./litmus_sb none 1000000 && run ./litmus_sb fence 1000000 ;;
  esac
)

stem_results() {
  python3 - "$root/STEM PROJECT/результати" <<'PY' || return
import csv
import sys
from collections import defaultdict
from pathlib import Path
from statistics import median

results = Path(sys.argv[1])
for arch, label in (('aarch64', 'ARM64'), ('x86_64', 'x86-64')):
    with (results / arch / 'e4_mechanisms.csv').open() as source:
        runs = defaultdict(list)
        for row in csv.DictReader(source):
            runs[row['mode']].append(row)

    print(f'\n{label} · E4 · 4 потоки × 1 000 000')
    for mode, group in runs.items():
        correct = sum(row['expected'] == row['actual'] for row in group)
        elapsed = median(float(row['time_ms']) for row in group)
        print(f'{mode:7s}  коректних {correct:2d}/{len(group)}  медіана {elapsed:7.2f} мс')

with (results / 'macos_arm64' / 'e9_litmus.csv').open() as source:
    rows = list(csv.DictReader(source))

print('\nmacOS ARM64 · Store Buffering з атомарними змінними')
for variant in ('none', 'fence'):
    group = [row for row in rows if row['variant'] == variant]
    both_zero = sum(int(row['reorders']) for row in group)
    iterations = sum(int(row['iters']) for row in group)
    print(f'{variant:7s}  результатів (0, 0) {both_zero:,} з {iterations:,}')
PY
  show "$root/STEM PROJECT/графіки/g4_mehanizmy.png"
}

demonstrate() {
  case "$lab:$1" in
    *:0) show "$report" ;;
    1:1)
      run sw_vers
      run uname -smr
      run ps -p 1 -o pid,comm
      printf '$ kmutil showloaded --list-only\n'
      kmutil showloaded --list-only 2>/dev/null | grep -E 'com\.apple\.kpi\.(bsd|iokit|mach)[[:space:]]' || shots 02 ;;
    1:2)
      run diskutil list internal
      printf '$ mount | grep " on / "\n'
      mount | grep ' on / '
      run csrutil status
      run fdesetup status ;;
    1:3) shots 10 11 12 ;;
    1:4) show "$report" ;;

    2:1) vm_start Zahorskyi_Win || shots 02 04 05 ;;
    2:2) vm_transfer_demo Zahorskyi_Win || shots 06 07 08 ;;
    2:3) shots 09 10 11 ;;
    2:4)
      vm_files Zahorskyi_Win "$vm_dir/Export/Zahorskyi_Win.ova" || true
      shots 12 13 14 15 ;;

    3:1) vm_start Zahorskyi_Ubuntu || shots 01 ;;
    3:2)
      vm_transfer_demo Zahorskyi_Ubuntu || shots 02 03 04 ;;
    3:3)
      run ls -l "$ubuntu_shared"
      shots 05 06 07 08 09 10 ;;
    3:4)
      vm_files Zahorskyi_Ubuntu "$HOME/VMs/oslabs/export/Zahorskyi_Ubuntu.ova" || true
      shots 11 12 13 14 15 ;;

    4:1) shots 01 02 ;;
    4:2)
      local results="$root/lab4/результати_PerfMon"
      show "$results"/{idle_modes,paint_modes,idle_interrupts,paint_interrupts}.gif ;;
    4:3) perf_summary ;;
    4:4) shots 08 ;;

    5:1) shots 01 02 03 04 ;;
    5:2) shots 05 06 08 09 ;;
    5:3) shots 11 12 13 15 ;;
    5:4) shots 14 ;;

    6:1) show "$root/STEM PROJECT/код/race_demo.c" ;;
    6:2) stem_run race_demo ;;
    6:3) stem_run race_trace ;;
    6:4) stem_results ;;
    6:5) stem_run bank global 4 250000 ;;
    6:6)
      local status=0
      stem_run bank fine_naive 4 250000 || status=$?
      # Код 3 означає, що watchdog зафіксував взаємне блокування.
      [[ $status == 3 ]] || return "$status" ;;
    6:7) stem_run bank fine_ordered 4 250000 ;;
    6:8) stem_run litmus_sb ;;
  esac
}

printf '%s\n' "$title"
if [[ $# == 2 ]]; then
  if [[ $2 == vm ]]; then open_lab_vm; else demonstrate "$2"; fi
  exit $?
fi

demonstrate 0 || exit
for ((i = 1; i <= ${#steps[@]}; i++)); do
  printf '\n[Enter] %d/%d · %s ' "$i" "${#steps[@]}" "${steps[i-1]}"
  IFS= read -r || exit 0
  demonstrate "$i" || exit
done
